﻿using System.Collections.Generic;
using System.Linq;

namespace WebApplication1.Repositories
{

    public class DatabaseRepository : IRepository<string, int>
    {
        void IRepository<string, int>.Add(string entity)
        {
            throw new System.NotImplementedException();
        }

        IEnumerable<string> IRepository<string, int>.Get()
        {
            throw new System.NotImplementedException();
        }

        string IRepository<string, int>.Get(int id)
        {
            throw new System.NotImplementedException();
        }

        void IRepository<string, int>.Remove(string entity)
        {
            throw new System.NotImplementedException();
        }
    }
}