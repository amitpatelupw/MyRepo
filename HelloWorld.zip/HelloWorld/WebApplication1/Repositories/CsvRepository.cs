﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Repositories
{
    public class CsvRepository : IRepository<string, int>
    {
       
        void IRepository<string, int>.Add(string entity)
        {
            throw new NotImplementedException();
        }

        IEnumerable<string> IRepository<string, int>.Get()
        {
            throw new NotImplementedException();
        }

        string IRepository<string, int>.Get(int id)
        {
            throw new NotImplementedException();
        }

        void IRepository<string, int>.Remove(string entity)
        {
            throw new NotImplementedException();
        }
    }
}