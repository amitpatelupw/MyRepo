﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim lblEventDate As System.Windows.Forms.Label
        Me.dtDate = New System.Windows.Forms.DateTimePicker()
        Me.lblDate = New System.Windows.Forms.Label()
        Me.lblBetType = New System.Windows.Forms.Label()
        Me.txtBetType = New System.Windows.Forms.TextBox()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.lblAmount = New System.Windows.Forms.Label()
        Me.txtEvent = New System.Windows.Forms.TextBox()
        Me.lblEvent = New System.Windows.Forms.Label()
        Me.dtlblEventDate = New System.Windows.Forms.DateTimePicker()
        Me.txtBookie = New System.Windows.Forms.TextBox()
        Me.lblBookie = New System.Windows.Forms.Label()
        Me.txtExchange = New System.Windows.Forms.TextBox()
        Me.lblExchange = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.btnPost = New System.Windows.Forms.Button()
        Me.DateTime = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.BetType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.EventName = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Bookie = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Exchange = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ExchangeDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblPath = New System.Windows.Forms.Label()
        lblEventDate = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dtDate
        '
        Me.dtDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtDate.Location = New System.Drawing.Point(148, 36)
        Me.dtDate.Name = "dtDate"
        Me.dtDate.Size = New System.Drawing.Size(86, 20)
        Me.dtDate.TabIndex = 0
        '
        'lblDate
        '
        Me.lblDate.AutoSize = True
        Me.lblDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDate.Location = New System.Drawing.Point(108, 43)
        Me.lblDate.Name = "lblDate"
        Me.lblDate.Size = New System.Drawing.Size(34, 13)
        Me.lblDate.TabIndex = 1
        Me.lblDate.Text = "Date"
        '
        'lblBetType
        '
        Me.lblBetType.AutoSize = True
        Me.lblBetType.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBetType.Location = New System.Drawing.Point(324, 42)
        Me.lblBetType.Name = "lblBetType"
        Me.lblBetType.Size = New System.Drawing.Size(58, 13)
        Me.lblBetType.TabIndex = 2
        Me.lblBetType.Text = "Bet Type"
        '
        'txtBetType
        '
        Me.txtBetType.Location = New System.Drawing.Point(383, 35)
        Me.txtBetType.Name = "txtBetType"
        Me.txtBetType.Size = New System.Drawing.Size(147, 20)
        Me.txtBetType.TabIndex = 3
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(597, 35)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(147, 20)
        Me.txtAmount.TabIndex = 5
        '
        'lblAmount
        '
        Me.lblAmount.AutoSize = True
        Me.lblAmount.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAmount.Location = New System.Drawing.Point(551, 42)
        Me.lblAmount.Name = "lblAmount"
        Me.lblAmount.Size = New System.Drawing.Size(49, 13)
        Me.lblAmount.TabIndex = 4
        Me.lblAmount.Text = "Amount"
        '
        'txtEvent
        '
        Me.txtEvent.Location = New System.Drawing.Point(799, 35)
        Me.txtEvent.Name = "txtEvent"
        Me.txtEvent.Size = New System.Drawing.Size(147, 20)
        Me.txtEvent.TabIndex = 7
        '
        'lblEvent
        '
        Me.lblEvent.AutoSize = True
        Me.lblEvent.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEvent.Location = New System.Drawing.Point(761, 42)
        Me.lblEvent.Name = "lblEvent"
        Me.lblEvent.Size = New System.Drawing.Size(40, 13)
        Me.lblEvent.TabIndex = 6
        Me.lblEvent.Text = "Event"
        '
        'lblEventDate
        '
        lblEventDate.AutoSize = True
        lblEventDate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        lblEventDate.Location = New System.Drawing.Point(1498, 42)
        lblEventDate.Name = "lblEventDate"
        lblEventDate.Size = New System.Drawing.Size(71, 13)
        lblEventDate.TabIndex = 9
        lblEventDate.Text = "Event Date"
        '
        'dtlblEventDate
        '
        Me.dtlblEventDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtlblEventDate.Location = New System.Drawing.Point(1575, 35)
        Me.dtlblEventDate.Name = "dtlblEventDate"
        Me.dtlblEventDate.Size = New System.Drawing.Size(96, 20)
        Me.dtlblEventDate.TabIndex = 8
        '
        'txtBookie
        '
        Me.txtBookie.Location = New System.Drawing.Point(1012, 35)
        Me.txtBookie.Name = "txtBookie"
        Me.txtBookie.Size = New System.Drawing.Size(147, 20)
        Me.txtBookie.TabIndex = 11
        '
        'lblBookie
        '
        Me.lblBookie.AutoSize = True
        Me.lblBookie.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBookie.Location = New System.Drawing.Point(964, 42)
        Me.lblBookie.Name = "lblBookie"
        Me.lblBookie.Size = New System.Drawing.Size(46, 13)
        Me.lblBookie.TabIndex = 10
        Me.lblBookie.Text = "Bookie"
        '
        'txtExchange
        '
        Me.txtExchange.Location = New System.Drawing.Point(1239, 35)
        Me.txtExchange.Name = "txtExchange"
        Me.txtExchange.Size = New System.Drawing.Size(147, 20)
        Me.txtExchange.TabIndex = 13
        '
        'lblExchange
        '
        Me.lblExchange.AutoSize = True
        Me.lblExchange.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblExchange.Location = New System.Drawing.Point(1174, 42)
        Me.lblExchange.Name = "lblExchange"
        Me.lblExchange.Size = New System.Drawing.Size(63, 13)
        Me.lblExchange.TabIndex = 12
        Me.lblExchange.Text = "Exchange"
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DateTime, Me.BetType, Me.Amount, Me.EventName, Me.Bookie, Me.Exchange, Me.ExchangeDate})
        Me.DataGridView1.Location = New System.Drawing.Point(111, 180)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(1560, 350)
        Me.DataGridView1.TabIndex = 14
        '
        'btnPost
        '
        Me.btnPost.Location = New System.Drawing.Point(111, 109)
        Me.btnPost.Name = "btnPost"
        Me.btnPost.Size = New System.Drawing.Size(1560, 23)
        Me.btnPost.TabIndex = 15
        Me.btnPost.Text = "Post"
        Me.btnPost.UseVisualStyleBackColor = True
        '
        'DateTime
        '
        Me.DateTime.HeaderText = "Date"
        Me.DateTime.Name = "DateTime"
        Me.DateTime.ReadOnly = True
        '
        'BetType
        '
        Me.BetType.HeaderText = "Bet Type"
        Me.BetType.Name = "BetType"
        Me.BetType.ReadOnly = True
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.ReadOnly = True
        '
        'EventName
        '
        Me.EventName.HeaderText = "Event"
        Me.EventName.Name = "EventName"
        Me.EventName.ReadOnly = True
        '
        'Bookie
        '
        Me.Bookie.HeaderText = "Bookie"
        Me.Bookie.Name = "Bookie"
        Me.Bookie.ReadOnly = True
        '
        'Exchange
        '
        Me.Exchange.HeaderText = "Exchange"
        Me.Exchange.Name = "Exchange"
        Me.Exchange.ReadOnly = True
        '
        'ExchangeDate
        '
        Me.ExchangeDate.HeaderText = "Exchange Date"
        Me.ExchangeDate.Name = "ExchangeDate"
        Me.ExchangeDate.ReadOnly = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(108, 577)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(69, 13)
        Me.Label1.TabIndex = 16
        Me.Label1.Text = "File Path : "
        '
        'lblPath
        '
        Me.lblPath.AutoSize = True
        Me.lblPath.Location = New System.Drawing.Point(183, 577)
        Me.lblPath.Name = "lblPath"
        Me.lblPath.Size = New System.Drawing.Size(0, 13)
        Me.lblPath.TabIndex = 17
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1787, 661)
        Me.Controls.Add(Me.lblPath)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnPost)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.txtExchange)
        Me.Controls.Add(Me.lblExchange)
        Me.Controls.Add(Me.txtBookie)
        Me.Controls.Add(Me.lblBookie)
        Me.Controls.Add(lblEventDate)
        Me.Controls.Add(Me.dtlblEventDate)
        Me.Controls.Add(Me.txtEvent)
        Me.Controls.Add(Me.lblEvent)
        Me.Controls.Add(Me.txtAmount)
        Me.Controls.Add(Me.lblAmount)
        Me.Controls.Add(Me.txtBetType)
        Me.Controls.Add(Me.lblBetType)
        Me.Controls.Add(Me.lblDate)
        Me.Controls.Add(Me.dtDate)
        Me.Name = "Form1"
        Me.Text = "MyBet"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtDate As DateTimePicker
    Friend WithEvents lblDate As Label
    Friend WithEvents lblBetType As Label
    Friend WithEvents txtBetType As TextBox
    Friend WithEvents txtAmount As TextBox
    Friend WithEvents lblAmount As Label
    Friend WithEvents txtEvent As TextBox
    Friend WithEvents lblEvent As Label
    Friend WithEvents dtlblEventDate As DateTimePicker
    Friend WithEvents txtBookie As TextBox
    Friend WithEvents lblBookie As Label
    Friend WithEvents txtExchange As TextBox
    Friend WithEvents lblExchange As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents btnPost As Button
    Friend WithEvents DateTime As DataGridViewTextBoxColumn
    Friend WithEvents BetType As DataGridViewTextBoxColumn
    Friend WithEvents Amount As DataGridViewTextBoxColumn
    Friend WithEvents EventName As DataGridViewTextBoxColumn
    Friend WithEvents Bookie As DataGridViewTextBoxColumn
    Friend WithEvents Exchange As DataGridViewTextBoxColumn
    Friend WithEvents ExchangeDate As DataGridViewTextBoxColumn
    Friend WithEvents Label1 As Label
    Friend WithEvents lblPath As Label
End Class
