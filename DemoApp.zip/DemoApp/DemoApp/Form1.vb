﻿Imports System.IO

Public Class Form1
    Dim fileName = (String.Format("{0}\Data\", Environment.CurrentDirectory).Split("\"))(0) + "\" + "DataImport.csv"
    Public Sub New()
        InitializeComponent()
        Me.BindDataGridView()
    End Sub

    Private Sub BindDataGridView()

        If File.Exists(fileName) Then

            Dim Lines As String() = File.ReadAllLines(fileName)
            Dim dt As New DataTable()
            If (Lines.Count > 0) Then
                Dim Fields As String()
                DataGridView1.Rows.Clear()
                For i As Integer = 1 To Lines.GetLength(0) - 1
                    Fields = Lines(i).Split(New Char() {","c})
                    DataGridView1.Rows.Add(Fields(0), Fields(1), Fields(2), Fields(3), Fields(4), Fields(5), Fields(6))
                Next

                '1st row must be column names; force lower case to ensure matching later on.
                'For i As Integer = 0 To Cols - 1
                '    dt.Columns.Add(Fields(i).ToLower(), GetType(String))
                'Next
                'Dim Row As DataGridView.
                'For i As Integer = 1 To Lines.GetLength(0) - 1
                '    Fields = Lines(i).Split(New Char() {","c})
                '    Row = dt.NewRow()
                '    For f As Integer = 0 To 7 - 1
                '        Row(f) = Fields(f)
                '    Next
                '    dt.Rows.Add(Row)
                'Next

                'DataGridView1.DataSource = dt
                'Else
                '    dt.Columns.AddRange(New DataColumn() {New DataColumn("Date", GetType(DateTime)),
                '                               New DataColumn("Bet Type", GetType(String)),
                '                               New DataColumn("Amount", GetType(String)),
                '                               New DataColumn("Event", GetType(String)),
                '                               New DataColumn("Bookie", GetType(String)),
                '                               New DataColumn("Exchange", GetType(String)),
                '                               New DataColumn("Exchange Date", GetType(String))
                '                               })
            End If

        End If
    End Sub
    Private Sub btnPost_Click(sender As Object, e As EventArgs) Handles btnPost.Click

        'Saved File location        

        'Build the CSV file data as a Comma separated string.
        Dim csv As String = String.Empty

        'Add the Header row for CSV file.
        For Each column As DataGridViewColumn In DataGridView1.Columns
            csv += column.HeaderText & ","c
        Next
        csv = csv.TrimEnd(",")
        'Add new line.
        csv += vbCr & vbLf

        'Adding the Rows
        For Each row As DataGridViewRow In DataGridView1.Rows
            For Each cell As DataGridViewCell In row.Cells
                'Add the Data rows.
                csv += cell.Value.ToString().Replace(",", ";") & ","c
            Next
            'Add new line.
            csv += vbCr & vbLf
        Next

        csv += dtDate.Value.ToString() + "," + txtBetType.Text + "," + txtAmount.Text + "," + txtEvent.Text + "," + txtBookie.Text + "," + txtExchange.Text + "," + dtlblEventDate.Value.ToString()
        csv += vbCr & vbLf
        'Exporting to Excel        

        If File.Exists(fileName) Then
            File.WriteAllText(fileName, csv)
        Else
            File.WriteAllText(fileName, csv)
        End If

        BindDataGridView()

        lblPath.Text = fileName
    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub
End Class
